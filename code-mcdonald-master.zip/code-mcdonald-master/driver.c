/*Test Driver Module to Run the Game*/

#include "display.h"

int main(void){

    Game game;
    Character c, x;
    Object o, a;
    Button b, m;
    unsigned int map[15][20];
    unsigned int ui_layout[15][20];
   
    CreateWindow(&game.window);
    game.characters = NULL;
    game.objects = NULL;
    game.char_num = 0;
    game.obj_num = 0;
    game.button_num = 0;

    MakeMapFromFile(map);
    MakeUILayout(ui_layout);

    game.ui = CreateUI(BUTTON_IMAGE, 0, 0, 0, 128);

    c = CreateCharacter("Ronald", SPRITE_IMAGE, 200, 100, 128, 0);
    x = CreateCharacter("McDonald", SPRITE_IMAGE, 100, 100, 128, 0);
    InsertNewCharacter(&game, c);
    InsertNewCharacter(&game, x);

    o = CreateObject("logs", OBJECT_IMAGE, 200, 200, 128, 320);
    a = CreateObject("morelogs", OBJECT_IMAGE, 320, 350, 128, 320);
 
   

    InsertNewObject(&game, o);
    InsertNewObject(&game, a);

    b = CreateButton("button", BUTTON_IMAGE, 600, 200, 0, 0, 32);
    m = CreateButton("anotherbutton", BUTTON_IMAGE, 5, 50, 0, 0, 32);
    InsertNewButton(&game, b);
    InsertNewUIButton(&game, m);

    SetTextures(&game, map, ui_layout);

    EventLoop(&game);

    SDL_FreeSurface(b.surface);
    SDL_DestroyTexture(b.texture);
    FreeGame(&game);

    return 0;

}

