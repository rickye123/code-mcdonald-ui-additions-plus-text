/*

Display Header File

Driver << Display >> Game(State) >> Characters >> Objects

*/

#include "game.h"

#define MILLISECOND_DELAY 20

unsigned int EventLoop(Game *g);
void Events(Game *g);



void DetermineBitImage(Window *win, unsigned int tiles[MAP_HEIGHT][MAP_WIDTH], int i, int j);
void SetWinBitmapPos(Window *window, unsigned int bit_x, unsigned int bit_y);


void SetTextures(Game *g, unsigned int tiles[MAP_HEIGHT][MAP_WIDTH], unsigned int ui_tiles[MAP_HEIGHT][MAP_WIDTH]);
void SetGameTexture(Game *g, unsigned int tiles[MAP_HEIGHT][MAP_WIDTH]);
void SetUITexture(Game *g, unsigned int ui_tiles[MAP_HEIGHT][MAP_WIDTH]);
void SetGamePieceTextures(Game *g);


void RenderAll(Game *game);
void RenderGameViewport(Game *g);
void RenderCharacters(Game *g);
void RenderObjects(Game *g);
void RenderButtons(Game *g);
void RenderUIViewport(Game *g);


void DetermineUIBitImage(UI *u, unsigned int tiles[MAP_HEIGHT][MAP_WIDTH], unsigned int i, unsigned int j);
void SetUIBitmapPos(UI *u, unsigned int bit_x, unsigned int bit_y);
